package Bai5_T39;
import java.text.DecimalFormat;
import java.util.Scanner;
public class Circle_Demo {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CircleCollection test = new CircleCollection();
		System.out.print("so luong hinh tron:");
		int n = new Scanner(System.in).nextInt();
		Circle c;
		for (int i = 0; i < n; i++) {
			c = new Circle();
			test.addCircle(c);
		}
		System.out.println("danh sach hinh tron");
		System.out.println(test.toString());
		System.out.println("tong dien tich cac hinh tron:"
		+ new DecimalFormat("0.###").format(test.getSumArea()));
	}

}
