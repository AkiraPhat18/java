package Bai5_T39;
import java.util.Scanner;
public class Demo {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CircleCollection test = new CircleCollection();
		Circle c;
		do{
			c= new Circle();
			test.addCircle(c);
			System.out.println(" đã nhập 1 hình tròn");
			System.out.println("co nhap nua khong?(C/K)");
			String tl = new Scanner(System.in).nextLine();
			if(tl.equalsIgnoreCase("K")) break;
		}while(true);
		System.out.println("danh sach hinh tron");
		System.out.println(test.toString());
		
	}
}
