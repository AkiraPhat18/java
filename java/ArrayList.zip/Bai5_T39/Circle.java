package Bai5_T39;
import java.text.DecimalFormat;
import java.util.Random;
import java.util.RandomAccess;
public class Circle {
	private int radius;
	public double getArea(){
		return Math.PI*radius*radius;
	}
	@Override
	public String toString() {
		DecimalFormat f = new DecimalFormat("#.00");
		return "radius=" + radius +
			   ", \tgetArea()=" + f.format(getArea()) ;
	}
	public Circle() {
		Random random = new Random();
		radius = random.nextInt(10);
	}
}
