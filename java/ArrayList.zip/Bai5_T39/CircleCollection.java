package Bai5_T39;
import java.util.ArrayList;
public class CircleCollection {
	ArrayList <Circle> arrCircle = new ArrayList();
	public boolean addCircle(Circle c){
		arrCircle.add(c);
		return true;
	}
	public int getSize(){
		return arrCircle.size();
	}
	public void setCircle(int i, Circle c){
		arrCircle.set(i, c);
	}
	public Circle get(int i){
		return arrCircle.get(i);
	}
	public double getSumArea(){
		double t=0;
		for (Circle circle : arrCircle) {
			t+=circle.getArea();
		}
		return t;
	}
	public String toString(){
		String  s="";
		for (Circle circle : arrCircle) {
			s+=circle.toString()+"\n";
		}
		return s;
	}
	public boolean remove(int i){
		arrCircle.remove(i); 
		return true;
	}
}
