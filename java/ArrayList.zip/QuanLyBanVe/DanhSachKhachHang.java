package QuanLyBanVe;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
public class DanhSachKhachHang {
	private ArrayList<KhachHang> dsDoiVe =new ArrayList();
	private ArrayList<KhachHang> dsCoVe= new ArrayList();
	public void themKhachDoiMua(KhachHang khNew) {
		dsDoiVe.add(khNew);
	}
	public boolean banVe() {
		if(dsDoiVe.size() > 0){
			KhachHang kh = dsDoiVe.get(0);
			// loại khách hàng đầu khỏi ds đợi mua
			dsDoiVe.remove(0);
			dsCoVe.add(kh);
			return true;
		}
		else
		{ System.out.println("Đã hết khách đợi mua vé");
		return false;
		}
	}
	public boolean huyKhachHang(String soCMND) {
		KhachHang kh = new KhachHang(soCMND);
		if(dsDoiVe.contains(kh)){
			dsDoiVe.remove(kh);
			return true;
		}
		return false;
	}
	public void	hienThiDSDoiVe() {
		System.out.println("Danh sách khách chưa có vé");
			for(KhachHang kh : dsDoiVe)
			System.out.println(kh);
		System.out.println("\t-----------------------");
	}
	public void hienThiDanhSachCoVe() {
		System.out.println("Danh sách khách có vé");
		for(KhachHang kh : dsCoVe)
			System.out.println(kh);
		System.out.println("\t-----------------------");
	}
	public double getTongTien(){
		double t=0;
		for (KhachHang khachHang : dsCoVe) {
			t+=khachHang.getGiaVe();
		}
		return t;
	}
	
}
