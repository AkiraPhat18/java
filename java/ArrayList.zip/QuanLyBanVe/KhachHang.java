package QuanLyBanVe;
import java.io.Serializable;
import java.text.DecimalFormat;
import java.util.Comparator;

import javax.swing.ComboBoxEditor;
public class KhachHang {
		private String soCMND;
		private String tenKh;
		private String gaDen;
		private double giaVe;
		public KhachHang (String soCMND) {
			this(soCMND,"","",0.0);
		}
		public KhachHang(String soCMND, String tenKh, String gaDen, double giaVe) {
			this.soCMND = soCMND;
			this.tenKh = tenKh;
			this.gaDen = gaDen;
			this.giaVe = giaVe;
		}
		
		public void setGaDen(String gaDen) {
			this.gaDen = gaDen;
		}
		
		public String getGaDen() {
			return gaDen;
		}
		
		public double getGiaVe() {
			return giaVe;
		}
		
		public void setGiaVe(double giaVe) {
			this.giaVe = giaVe;
		}
		
		public String getSoCMND() {
			return soCMND;
		}
		
		@Override
		public String toString() {
			DecimalFormat df = new DecimalFormat("#,##0 VND");
			return String.format("%-5s %-10s %-10s %10s ", 
					soCMND, tenKh, gaDen, df.format(giaVe));
		}
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((soCMND == null) ? 0 : soCMND.hashCode());
			return result;
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			KhachHang other = (KhachHang) obj;
			if (soCMND == null) {
				if (other.soCMND != null)
					return false;
			} else if (!soCMND.equals(other.soCMND))
				return false;
			return true;
		}
		
	}


