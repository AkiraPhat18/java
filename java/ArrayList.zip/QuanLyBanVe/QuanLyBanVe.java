package QuanLyBanVe;

import java.text.DecimalFormat;
import java.util.Scanner;
public class QuanLyBanVe {
	 static DanhSachKhachHang ds = new DanhSachKhachHang();
	public static void main(String args[]){
		Scanner in = new Scanner(System.in);
		do{
			System.out.println("\t********Công việc***********");
			System.out.println("\t1. Thêm khách đợi mua vé");
			System.out.println("\t2. Bán vé cho khách ");
			System.out.println("\t3. Hủy bán vé");
			System.out.println("\t4. Thống kê");
			System.out.println("\t5. Thoát");
			System.out.print("\t\tBạn chọn ? : ");
			int tl = new Scanner(System.in).nextInt();
			switch (tl) {
			case 1:
				themKhach();break;
			case 2:
				banVe();break;
			case 3:
				huy();	break;
			case 4:
				thongKe();
				break;
			case 5:
				System.exit(0);	
				break;
			}
			
		}while(true);
	}

	private static void themKhach() {
		Scanner in = new Scanner(System.in);
		System.out.print("so CMND:");
		String soCMND = in.nextLine();
		System.out.print("Ho ten:"); String ten = in.nextLine();
		System.out.print("Ga den:"); String ga = in.nextLine();
		System.out.print("Gia ve:");  double gia = in.nextDouble();
		in.nextLine();
		KhachHang khNew = new KhachHang(soCMND, ten, ga, gia);
		ds.themKhachDoiMua(khNew);
	}
	private static void banVe() {
		if(ds.banVe())
			System.out.println("Bán thành công!");
	}
	private static void huy() {
		System.out.println("nhập CMND của khách hàng hủy mua vé:");
		String soCMND = new Scanner(System.in).nextLine();
	if(ds.huyKhachHang(soCMND))
		System.out.println("Hủy thành công!");
	else
		System.out.println("không tìm thấy thông tin");
		
	}
	private static void thongKe() {
		ds.hienThiDanhSachCoVe();
		ds.hienThiDSDoiVe();
		System.out.println("\ttổng tiền bán vé: " 
		+ new DecimalFormat("#.##").format(ds.getTongTien()) +"VNĐ");
		System.out.println("\t***********************\n");
	}

}
