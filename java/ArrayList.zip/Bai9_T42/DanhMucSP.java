package Bai9_T42;
import java.util.ArrayList;
import java.util.Scanner;
public class DanhMucSP {
	private String maDM,tenDM;
	ArrayList< SanPham> dsSanPham = new ArrayList<>();
	public void nhap() throws Exception{
		Scanner in = new Scanner(System.in);
		System.out.print("ma danh muc:");
		maDM = in.nextLine();
		if (maDM.equals("")) throw new Exception("Dừng nhâp!");
		System.out.print("ten danh muc:");
		tenDM = in.nextLine();
		do {
			SanPham sp = new SanPham();
			sp.nhap();
			dsSanPham.add(sp);
			System.out.print("nhap nua khong?(C/K)");
			String tl = in.nextLine();
			if(tl.equalsIgnoreCase("K")) break;
		}while (true);
	}
	public void capNhatTTSP(String maSP){
		SanPham temp = new SanPham(maSP);
		if(!dsSanPham.contains(temp)){
			System.out.println("khong tim duoc");
		}
		else
		{
			SanPham sanPham = new SanPham();
			sanPham.nhap();
			dsSanPham.set(dsSanPham.indexOf(temp), sanPham);
		}
	}
	public void xoa(String maSP){
		SanPham temp = new SanPham(maSP);
		if(!dsSanPham.contains(temp)){
			System.out.println("khong tim duoc");
		}
		else
		{
			dsSanPham.remove(dsSanPham.indexOf(temp));
		}
	}
	public float tongTien() {
		float tong=0;
		for (SanPham sanPham : dsSanPham) {
			
			tong+=sanPham.gia ;
		}
		return tong;
	}
	@Override
	public String toString() {
		String s = "maDM=" + maDM + ", tenDM=" + tenDM +"\n";
		s+= "\t\tdanh sach san pham trong danh muc\n";
		for (SanPham sanPham : dsSanPham) {
			
			s+=sanPham.toString() + "\n";
		}
		return s;
	}
	public DanhMucSP() {
		super();
	}
	public DanhMucSP(String maDM) {
		super();
		this.maDM = maDM;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((maDM == null) ? 0 : maDM.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DanhMucSP other = (DanhMucSP) obj;
		if (maDM == null) {
			if (other.maDM != null)
				return false;
		} else if (!maDM.equals(other.maDM))
			return false;
		return true;
	}
	public void lietKeSP(){
		for (SanPham sanPham : dsSanPham) {
			if (sanPham.xuatXu.equalsIgnoreCase("Trung quoc"))
				System.out.println(sanPham);
		}
	}

}
