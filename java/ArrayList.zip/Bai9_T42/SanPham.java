package Bai9_T42;
import java.util.Scanner;
public class SanPham {
String maSP, tenSP;
float gia;
String xuatXu;
public void nhap(){
	Scanner in  = new Scanner(System.in);
	System.out.print("ma san pham: ");
	maSP = in.nextLine();
	System.out.print("ten san pham: ");
	tenSP = in.nextLine();
	System.out.print("gia: ");
	gia = in.nextFloat(); in.nextLine();
	System.out.print("xuat xu: ");
	xuatXu = in.nextLine();
}
@Override
public String toString() {
	return "\t\tmaSP=" + maSP + ", tenSP=" + tenSP + ", gia=" + gia + ", xuatXu=" + xuatXu ;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((maSP == null) ? 0 : maSP.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	SanPham other = (SanPham) obj;
	if (maSP == null) {
		if (other.maSP != null)
			return false;
	} else if (!maSP.equals(other.maSP))
		return false;
	return true;
}
public SanPham() {
	super();
}
public SanPham(String maSP) {
	super();
	this.maSP = maSP;
}

}

