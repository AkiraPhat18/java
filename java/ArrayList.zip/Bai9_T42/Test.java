package Bai9_T42;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Scanner;

public class Test {
static ArrayList <DanhMucSP> mangDM = new ArrayList();
	public static void main(String[] args) {
		nhap();
		xuat();
		capnhat();
		xoa();
		thongke();
		lietKe();
	}
	private static void lietKe() {
		for (DanhMucSP danhMucSP : mangDM) {
			danhMucSP.lietKeSP();
		}
		
	}
	private static void nhap() {
		do{
			DanhMucSP dm = new DanhMucSP();
			try {
				dm.nhap();
			} catch (Exception e) {
				break;
			}
			mangDM.add(dm);
		}while(true);
		
	}
	private static void xuat() {
	System.out.println("thông tin danh mục vừa nhập:");
	for (DanhMucSP danhMucSP : mangDM) {
		System.out.println(danhMucSP);
	}
	}
	private static void capnhat() {
		Scanner in  = new Scanner(System.in);
		System.out.print("Ma danh muc can cap nhat san pham:");
		String maDM = in.nextLine();
		DanhMucSP dMucSua = new DanhMucSP(maDM);
		if (!mangDM.contains(dMucSua))
			System.out.println("khong co danh muc: "+ maDM);
		else
		{	System.out.println("ma san pham can sua");
			String maSP = in.nextLine();
			int vt = mangDM.indexOf(dMucSua);
			mangDM.get(vt).capNhatTTSP(maSP);
			xuat();
		}
}
	private static void xoa() {
		// TODO Auto-generated method stub
		
	}
	
	private static void thongke() {
		float tTien=0;
		for (DanhMucSP danhMucSP : mangDM) {
			tTien +=danhMucSP.tongTien();
		}
	System.out.println("tổng giá trị các mặt hàng: " +
		new DecimalFormat("#.##").format(tTien));	
	}
}
